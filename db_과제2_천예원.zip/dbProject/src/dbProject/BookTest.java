package dbProject;

import java.util.Scanner;

public class BookTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		
		BookDTO bookDTO = new BookDTO();
		System.out.println("도서 정보를 입력하세요");
		bookDTO.setBookNo(s.nextLine());
		bookDTO.setBookTitle(s.nextLine());
		bookDTO.setBookAuthor(s.nextLine());
		bookDTO.setBookYear(s.nextInt());
		bookDTO.setBookPrice(s.nextInt());
		s.nextLine();
		bookDTO.setBookPublisher(s.nextLine());
		
		BookDAO bookDAO = new BookDAO();
		bookDAO.insertBook(bookDTO);
		bookDAO.selectBook();
	}
}