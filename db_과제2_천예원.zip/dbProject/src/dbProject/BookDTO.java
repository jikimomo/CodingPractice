package dbProject;

public class BookDTO {
	private String bookNo;
	private String bookTitle;
	private String bookAuthor;
	private int bookYear;
	private int bookPrice;
	private String bookPublisher;
	
	public String getBookNo() {
		return this.bookNo;
	}
	public void setBookNo(String bookNo) {
		this.bookNo = bookNo;
	}
	
	public String getBookTitle() {
		return this.bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	
	public String getBookAuthor() {
		return this.bookAuthor;
	}
	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}
	
	public int getBookYear() {
		return this.bookYear;
	}
	public void setBookYear(int bookYear) {
		this.bookYear = bookYear;
	}
	
	public int getBookPrice() {
		return this.bookPrice;
	}
	public void setBookPrice(int bookPrice) {
		this.bookPrice = bookPrice;
	}
	
	public String getBookPublisher() {
		return this.bookPublisher;
	}
	public void setBookPublisher(String bookPublisher) {
		this.bookPublisher = bookPublisher;
	}
	
	public String toString() {
		return bookNo+" "+bookTitle+" "+bookAuthor+" "+bookYear+" "+bookPrice+" "+bookPublisher;
	}
}
