package dbProject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class BookDAO {
	public static Connection getConnection() {
		String url = "jdbc:mysql://localhost:3306/shopdb";
		String driver = "com.mysql.cj.jdbc.Driver";
		String id = "root";
		String pwd = "mcys1309";
		
		Connection con = null;
		
		try {
			Class.forName(driver);
			con = DriverManager.getConnection(url, id, pwd);
			//System.out.println("connection success");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return con;
	}
	
	public void insertBook(BookDTO bookDTO) {
		Connection con = getConnection();
		Statement stmt = null;
		String sql = "insert into book values('"+bookDTO.getBookNo()+"', '"+bookDTO.getBookTitle()+"', '"+bookDTO.getBookAuthor()+"', "+bookDTO.getBookYear()+", "+bookDTO.getBookPrice()+", '"+bookDTO.getBookPublisher()+"')";
		
		try {
			stmt = con.createStatement();
			int affectedNum = stmt.executeUpdate(sql);
			
			if(affectedNum > 0)
				System.out.println("insert success");
			else
				System.out.println("insert fail");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void selectBook() {
		Connection con = getConnection();
		Statement stmt = null;
		String sql = "select * from book";
		
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getString(6));
			}
			rs.close();
			stmt.close();
			con.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
